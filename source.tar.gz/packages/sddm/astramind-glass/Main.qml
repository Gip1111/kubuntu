import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import SddmComponents 2.0

Rectangle {
    id: root
    width: 1920
    height: 1080
    color: "#05070d"

    property string selectedUser: userModel.lastUser
    property int selectedSession: sessionModel.lastIndex

    Image {
        anchors.fill: parent
        source: config.background
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
    }

    Rectangle {
        anchors.fill: parent
        color: "#05070d"
        opacity: 0.34
    }

    ColumnLayout {
        width: Math.min(430, root.width * 0.86)
        anchors.centerIn: parent
        spacing: 18

        Image {
            source: config.logo
            Layout.alignment: Qt.AlignHCenter
            Layout.preferredWidth: 92
            Layout.preferredHeight: 92
            fillMode: Image.PreserveAspectFit
        }

        Text {
            text: "AstraMind Glass"
            color: "#eafcff"
            font.pixelSize: 34
            font.bold: true
            horizontalAlignment: Text.AlignHCenter
            Layout.fillWidth: true
        }

        Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: 1
            color: "#00f0ff"
            opacity: 0.55
        }

        ComboBox {
            id: users
            Layout.fillWidth: true
            model: userModel
            textRole: "name"
            onCurrentTextChanged: root.selectedUser = currentText
        }

        TextField {
            id: password
            Layout.fillWidth: true
            placeholderText: "Password"
            echoMode: TextInput.Password
            focus: true
            onAccepted: loginButton.clicked()
        }

        ComboBox {
            id: sessions
            Layout.fillWidth: true
            model: sessionModel
            textRole: "name"
            currentIndex: root.selectedSession
            onCurrentIndexChanged: root.selectedSession = currentIndex
        }

        Button {
            id: loginButton
            text: "Accedi"
            Layout.fillWidth: true
            onClicked: sddm.login(root.selectedUser, password.text, root.selectedSession)
        }

        Text {
            id: errorMessage
            text: ""
            color: "#ff6f91"
            wrapMode: Text.WordWrap
            horizontalAlignment: Text.AlignHCenter
            Layout.fillWidth: true
        }
    }

    Row {
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 28
        spacing: 12

        Button {
            text: "Riavvia"
            onClicked: sddm.reboot()
        }

        Button {
            text: "Spegni"
            onClicked: sddm.powerOff()
        }
    }

    Connections {
        target: sddm
        function onLoginFailed() {
            password.text = ""
            errorMessage.text = "Accesso non riuscito"
            password.forceActiveFocus()
        }
    }
}

