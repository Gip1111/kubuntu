var panel = new Panel
panel.location = "bottom"
panel.height = 54
panel.alignment = "center"
panel.floating = true

var launcher = panel.addWidget("org.kde.plasma.kickoff")
launcher.currentConfigGroup = ["General"]
launcher.writeConfig("icon", "astramind")

var astra = panel.addWidget("org.kde.plasma.icon")
astra.currentConfigGroup = ["General"]
astra.writeConfig("url", "applications:astramind.desktop")

panel.addWidget("org.kde.plasma.icontasks")
panel.addWidget("org.kde.plasma.marginsseparator")
panel.addWidget("org.kde.plasma.systemtray")
panel.addWidget("org.kde.plasma.digitalclock")

for (var i = 0; i < screenCount; ++i) {
    var desktop = desktopForScreen(i)
    desktop.wallpaperPlugin = "org.kde.image"
    desktop.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"]
    desktop.writeConfig("Image", "file:///usr/share/wallpapers/AstraMindGlass/contents/images/3840x2160.svg")
}

