import QtQuick
import QtQuick.Controls

Rectangle {
    id: root
    color: "#05070d"

    Image {
        anchors.fill: parent
        source: "images/splash.svg"
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
    }

    Column {
        anchors.centerIn: parent
        spacing: 18

        Text {
            text: "AstraMind"
            color: "#eafcff"
            font.pixelSize: Math.max(42, root.height * 0.06)
            font.weight: Font.DemiBold
            horizontalAlignment: Text.AlignHCenter
        }

        Rectangle {
            width: 260
            height: 4
            radius: 2
            color: "#00f0ff"
            opacity: 0.85
        }

        Text {
            text: "Glass desktop assistant"
            color: "#9eefff"
            font.pixelSize: 18
            horizontalAlignment: Text.AlignHCenter
        }
    }
}

