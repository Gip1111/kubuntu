import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.components as PlasmaComponents
import org.kde.kirigami as Kirigami

PlasmoidItem {
    id: root
    width: Kirigami.Units.gridUnit * 12
    height: Kirigami.Units.gridUnit * 8
    preferredRepresentation: compactRepresentation
    Plasmoid.icon: "astramind"
    Plasmoid.title: "AstraMind"
    Plasmoid.toolTipMainText: "AstraMind"
    Plasmoid.toolTipSubText: "Assistente smart per KDE"

    function openAssistant() {
        Qt.openUrlExternally("applications:astramind.desktop")
    }

    compactRepresentation: Item {
        implicitWidth: Kirigami.Units.iconSizes.medium
        implicitHeight: Kirigami.Units.iconSizes.medium

        Kirigami.Icon {
            anchors.fill: parent
            source: "astramind"
        }

        MouseArea {
            anchors.fill: parent
            hoverEnabled: true
            onClicked: root.openAssistant()
        }
    }

    fullRepresentation: Rectangle {
        implicitWidth: Kirigami.Units.gridUnit * 13
        implicitHeight: Kirigami.Units.gridUnit * 8
        radius: 10
        color: "#0b1420"
        border.color: "#00f0ff"
        border.width: 1

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: Kirigami.Units.largeSpacing
            spacing: Kirigami.Units.smallSpacing

            Kirigami.Icon {
                source: "astramind"
                Layout.alignment: Qt.AlignHCenter
                Layout.preferredWidth: Kirigami.Units.iconSizes.large
                Layout.preferredHeight: Kirigami.Units.iconSizes.large
            }

            PlasmaComponents.Label {
                text: "AstraMind"
                horizontalAlignment: Text.AlignHCenter
                Layout.fillWidth: true
                color: "#eafcff"
                font.bold: true
            }

            PlasmaComponents.Button {
                text: "Apri"
                Layout.alignment: Qt.AlignHCenter
                onClicked: root.openAssistant()
            }
        }
    }
}

