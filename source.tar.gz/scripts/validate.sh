#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "[validate] bash syntax"
bash -n "$ROOT_DIR/install.sh"
bash -n "$ROOT_DIR/uninstall.sh"

echo "[validate] python syntax"
python3 -m py_compile "$ROOT_DIR/assistant/astramind.py" "$ROOT_DIR/assistant/astramind-gui.py"

echo "[validate] json"
python3 - <<'PY' "$ROOT_DIR"
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
for path in [
    root / "assistant" / "intents.json",
    root / "packages" / "plasma" / "look-and-feel" / "com.astramind.glass" / "manifest.json",
    root / "packages" / "plasma" / "look-and-feel" / "com.astramind.glass" / "metadata.json",
    root / "packages" / "plasma" / "wallpapers" / "AstraMindGlass" / "metadata.json",
    root / "packages" / "plasma" / "plasmoids" / "com.astramind.assistant" / "metadata.json",
]:
    with path.open("r", encoding="utf-8") as fh:
        json.load(fh)
    print(f"ok {path.relative_to(root)}")
PY

echo "[validate] required files"
test -f "$ROOT_DIR/packages/sddm/astramind-glass/Main.qml"
test -f "$ROOT_DIR/packages/plasma/color-schemes/AstraMindGlass.colors"
test -f "$ROOT_DIR/packages/kio/servicemenus/astramind.desktop"
test -f "$ROOT_DIR/packages/icons/astramind.svg"

echo "[validate] ok"

