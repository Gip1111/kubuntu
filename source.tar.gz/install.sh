#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_NAME="AstraMind Glass"
THEME_ID="com.astramind.glass"
DESKTOP_THEME="AstraMindGlass"
SDDM_THEME="astramind-glass"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="/var/backups/astramind-glass/${STAMP}"
STATE_DIR="/var/lib/astramind-glass"

log() {
  printf '[AstraMind] %s\n' "$*"
}

warn() {
  printf '[AstraMind][WARN] %s\n' "$*" >&2
}

die() {
  printf '[AstraMind][ERROR] %s\n' "$*" >&2
  exit 1
}

confirm() {
  if [[ "${ASTRA_ASSUME_YES:-0}" == "1" ]]; then
    return 0
  fi
  read -r -p "$1 [s/N] " answer
  case "${answer,,}" in
    s|si|y|yes) return 0 ;;
    *) return 1 ;;
  esac
}

need_cmd() {
  command -v "$1" >/dev/null 2>&1
}

require_root_tools() {
  need_cmd sudo || die "sudo non trovato."
  need_cmd install || die "install non trovato."
  need_cmd cp || die "cp non trovato."
  need_cmd python3 || die "python3 non trovato."
}

detect_plasma() {
  if [[ "${ASTRA_SKIP_APPLY:-0}" == "1" || "${ASTRA_HEADLESS:-0}" == "1" ]]; then
    log "Salto rilevamento Plasma interattivo per modalita build/headless."
    return
  fi

  if ! need_cmd plasmashell; then
    warn "plasmashell non trovato. Continuo solo se forzi con ASTRA_FORCE=1."
    [[ "${ASTRA_FORCE:-0}" == "1" ]] || die "KDE Plasma non rilevato."
    return
  fi

  local version major
  version="$(plasmashell --version | awk '{print $2}' | head -n1)"
  major="${version%%.*}"
  log "Plasma rilevato: ${version:-sconosciuto}"

  if [[ -n "$major" && "$major" =~ ^[0-9]+$ && "$major" -lt 6 ]]; then
    warn "Questo pacchetto e pensato per Plasma 6. Versione rilevata: $version"
    [[ "${ASTRA_FORCE:-0}" == "1" ]] || die "Interrompo per evitare incompatibilita. Usa ASTRA_FORCE=1 solo se sai cosa stai facendo."
  fi
}

backup_path() {
  local path="$1"
  if [[ -e "$path" || -L "$path" ]]; then
    sudo install -d "$BACKUP_DIR$(dirname "$path")"
    sudo cp -a "$path" "$BACKUP_DIR$path"
    log "Backup: $path"
  fi
}

copy_dir() {
  local src="$1"
  local dst="$2"
  [[ -d "$src" ]] || die "Directory sorgente mancante: $src"
  backup_path "$dst"
  sudo rm -rf "$dst"
  sudo install -d "$(dirname "$dst")"
  sudo cp -a "$src" "$dst"
}

copy_file() {
  local src="$1"
  local dst="$2"
  [[ -f "$src" ]] || die "File sorgente mancante: $src"
  backup_path "$dst"
  sudo install -d "$(dirname "$dst")"
  sudo install -m 0644 "$src" "$dst"
}

copy_executable() {
  local src="$1"
  local dst="$2"
  [[ -f "$src" ]] || die "File sorgente mancante: $src"
  backup_path "$dst"
  sudo install -d "$(dirname "$dst")"
  sudo install -m 0755 "$src" "$dst"
}

maybe_install_deps() {
  local missing=()
  local cmd
  for cmd in kdialog plasma-discover lookandfeeltool kcmshell6 kbuildsycoca6; do
    need_cmd "$cmd" || missing+=("$cmd")
  done

  if ((${#missing[@]} == 0)); then
    return
  fi

  warn "Comandi KDE mancanti o non nel PATH: ${missing[*]}"
  if need_cmd apt && confirm "Vuoi provare a installare i pacchetti KDE consigliati con apt?"; then
    sudo apt update
    sudo apt install -y kdialog plasma-discover kde-cli-tools
  else
    warn "Continuo. Alcune applicazioni potranno usare fallback."
  fi
}

install_files() {
  log "Installo componenti di sistema..."
  sudo install -d "$BACKUP_DIR" "$STATE_DIR"

  copy_dir "$ROOT_DIR/packages/plasma/look-and-feel/${THEME_ID}" "/usr/share/plasma/look-and-feel/${THEME_ID}"
  copy_dir "$ROOT_DIR/packages/plasma/desktoptheme/${DESKTOP_THEME}" "/usr/share/plasma/desktoptheme/${DESKTOP_THEME}"
  copy_dir "$ROOT_DIR/packages/plasma/wallpapers/AstraMindGlass" "/usr/share/wallpapers/AstraMindGlass"
  copy_dir "$ROOT_DIR/packages/plasma/plasmoids/com.astramind.assistant" "/usr/share/plasma/plasmoids/com.astramind.assistant"
  copy_dir "$ROOT_DIR/packages/sddm/${SDDM_THEME}" "/usr/share/sddm/themes/${SDDM_THEME}"
  copy_dir "$ROOT_DIR/assistant/guides" "/usr/share/astramind/guides"

  copy_file "$ROOT_DIR/packages/plasma/color-schemes/AstraMindGlass.colors" "/usr/share/color-schemes/AstraMindGlass.colors"
  copy_file "$ROOT_DIR/packages/applications/astramind.desktop" "/usr/share/applications/astramind.desktop"
  copy_file "$ROOT_DIR/packages/kio/servicemenus/astramind.desktop" "/usr/share/kio/servicemenus/astramind.desktop"
  copy_file "$ROOT_DIR/packages/icons/astramind.svg" "/usr/share/icons/hicolor/scalable/apps/astramind.svg"
  copy_file "$ROOT_DIR/assistant/intents.json" "/usr/share/astramind/intents.json"

  copy_executable "$ROOT_DIR/assistant/astramind.py" "/usr/bin/astramind"
  copy_executable "$ROOT_DIR/assistant/astramind-gui.py" "/usr/bin/astramind-gui"

  printf '%s\n' "$BACKUP_DIR" | sudo tee "$STATE_DIR/last-backup" >/dev/null
}

apply_plasma_theme() {
  log "Applico tema Plasma quando gli strumenti sono disponibili..."

  if need_cmd lookandfeeltool; then
    lookandfeeltool -a "$THEME_ID" || lookandfeeltool --apply "$THEME_ID" || warn "lookandfeeltool non e riuscito ad applicare $THEME_ID."
  fi

  if need_cmd plasma-apply-colorscheme; then
    plasma-apply-colorscheme "$DESKTOP_THEME" || warn "Color scheme non applicato automaticamente."
  fi

  if need_cmd plasma-apply-desktoptheme; then
    plasma-apply-desktoptheme "$DESKTOP_THEME" || warn "Desktop theme non applicato automaticamente."
  fi

  if need_cmd plasma-apply-wallpaperimage; then
    plasma-apply-wallpaperimage "/usr/share/wallpapers/AstraMindGlass/contents/images/3840x2160.svg" || warn "Wallpaper non applicato automaticamente."
  fi

  if need_cmd kbuildsycoca6; then
    kbuildsycoca6 || true
  elif need_cmd kbuildsycoca5; then
    kbuildsycoca5 || true
  fi
}

apply_sddm_theme() {
  local conf="/etc/sddm.conf.d/astramind-glass.conf"

  if ! confirm "Vuoi impostare anche il tema login SDDM di sistema?"; then
    warn "Tema SDDM installato ma non applicato."
    return
  fi

  backup_path "$conf"
  sudo install -d /etc/sddm.conf.d
  sudo tee "$conf" >/dev/null <<EOF
[Theme]
Current=${SDDM_THEME}
EOF
  log "Tema SDDM impostato in $conf"
}

main() {
  require_root_tools
  detect_plasma
  maybe_install_deps
  install_files

  if [[ "${ASTRA_SKIP_APPLY:-0}" == "1" ]]; then
    log "Salto applicazione tema sessione/SDDM per modalita build."
  else
    apply_plasma_theme
    apply_sddm_theme
  fi

  log "Installazione completata."
  log "Prova: astramind \"configura wifi\""
  log "Per rimuovere: sudo bash $ROOT_DIR/uninstall.sh"
}

main "$@"
