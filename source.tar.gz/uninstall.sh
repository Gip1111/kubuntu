#!/usr/bin/env bash
set -Eeuo pipefail

THEME_ID="com.astramind.glass"
DESKTOP_THEME="AstraMindGlass"
SDDM_THEME="astramind-glass"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="/var/backups/astramind-glass/uninstall-${STAMP}"

log() {
  printf '[AstraMind] %s\n' "$*"
}

backup_path() {
  local path="$1"
  if [[ -e "$path" || -L "$path" ]]; then
    sudo install -d "$BACKUP_DIR$(dirname "$path")"
    sudo cp -a "$path" "$BACKUP_DIR$path"
  fi
}

remove_path() {
  local path="$1"
  backup_path "$path"
  sudo rm -rf "$path"
  log "Rimosso: $path"
}

main() {
  sudo install -d "$BACKUP_DIR"

  remove_path "/usr/share/plasma/look-and-feel/${THEME_ID}"
  remove_path "/usr/share/plasma/desktoptheme/${DESKTOP_THEME}"
  remove_path "/usr/share/plasma/plasmoids/com.astramind.assistant"
  remove_path "/usr/share/wallpapers/AstraMindGlass"
  remove_path "/usr/share/sddm/themes/${SDDM_THEME}"
  remove_path "/usr/share/color-schemes/AstraMindGlass.colors"
  remove_path "/usr/share/applications/astramind.desktop"
  remove_path "/usr/share/kio/servicemenus/astramind.desktop"
  remove_path "/usr/share/icons/hicolor/scalable/apps/astramind.svg"
  remove_path "/usr/share/astramind"
  remove_path "/usr/bin/astramind"
  remove_path "/usr/bin/astramind-gui"
  remove_path "/etc/sddm.conf.d/astramind-glass.conf"
  remove_path "/var/lib/astramind-glass"

  if command -v kbuildsycoca6 >/dev/null 2>&1; then
    kbuildsycoca6 || true
  elif command -v kbuildsycoca5 >/dev/null 2>&1; then
    kbuildsycoca5 || true
  fi

  log "Disinstallazione completata. Backup creato in $BACKUP_DIR"
  log "Se il tema era attivo, seleziona Breeze da Impostazioni di sistema."
}

main "$@"

