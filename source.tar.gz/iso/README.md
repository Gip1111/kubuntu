# ISO builder

Questo builder crea una ISO live/installabile basata sulla ISO ufficiale Kubuntu 26.04 LTS AMD64.

## Build locale

Serve Linux con almeno 25 GB liberi:

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl xorriso squashfs-tools rsync grub-pc-bin grub-efi-amd64-bin isolinux mtools
sudo bash iso/build-iso.sh
```

Output:

```text
dist/astramind-kubuntu-26.04-amd64.iso
dist/astramind-kubuntu-26.04-amd64.iso.sha256
```

## Variabili utili

```bash
KUBUNTU_VERSION=26.04
ARCH=amd64
ISO_URL=https://cdimage.ubuntu.com/kubuntu/releases/26.04/release/kubuntu-26.04-desktop-amd64.iso
WORK_DIR=/percorso/work
DIST_DIR=/percorso/dist
```

## Cosa viene integrato

- tema Plasma AstraMind Glass;
- tema SDDM;
- wallpaper e splash;
- assistente smart offline;
- launcher nel menu applicazioni;
- menu Dolphin;
- configurazione `/etc/skel` per nuovi utenti/live user;
- guida offline.

