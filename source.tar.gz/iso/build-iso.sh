#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
KUBUNTU_VERSION="${KUBUNTU_VERSION:-26.04}"
ARCH="${ARCH:-amd64}"
BASE_NAME="kubuntu-${KUBUNTU_VERSION}-desktop-${ARCH}"
PRIMARY_BASE_URL="https://cdimage.ubuntu.com/kubuntu/releases/${KUBUNTU_VERSION}/release"
FALLBACK_BASE_URL="https://cdimage.ubuntu.com/cdimage/kubuntu/releases/${KUBUNTU_VERSION}/release"
WORK_DIR="${WORK_DIR:-${ROOT_DIR}/work/iso}"
DIST_DIR="${DIST_DIR:-${ROOT_DIR}/dist}"
BASE_ISO="${WORK_DIR}/${BASE_NAME}.iso"
EXTRACT_DIR="${WORK_DIR}/extract"
CHROOT_DIR="${WORK_DIR}/chroot"
OUTPUT_ISO="${DIST_DIR}/astramind-kubuntu-${KUBUNTU_VERSION}-${ARCH}.iso"
VOLUME_ID="ASTRAMIND_KUBUNTU_2604"

log() {
  printf '[iso] %s\n' "$*"
}

die() {
  printf '[iso][ERROR] %s\n' "$*" >&2
  exit 1
}

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "Comando mancante: $1"
}

require_root() {
  if [[ "${EUID}" -ne 0 ]]; then
    die "Esegui con sudo/root: sudo bash iso/build-iso.sh"
  fi
}

require_tools() {
  local cmd
  for cmd in curl xorriso unsquashfs mksquashfs rsync chroot mount umount find sha256sum awk sed sort du; do
    need_cmd "$cmd"
  done
}

resolve_iso_url() {
  if [[ -n "${ISO_URL:-}" ]]; then
    printf '%s\n' "$ISO_URL"
    return
  fi

  local primary="${PRIMARY_BASE_URL}/${BASE_NAME}.iso"
  local fallback="${FALLBACK_BASE_URL}/${BASE_NAME}.iso"

  if curl -fsIL "$primary" >/dev/null; then
    printf '%s\n' "$primary"
  elif curl -fsIL "$fallback" >/dev/null; then
    printf '%s\n' "$fallback"
  else
    die "Non trovo la ISO Kubuntu: $primary oppure $fallback"
  fi
}

download_iso() {
  install -d "$WORK_DIR" "$DIST_DIR"
  local url
  url="$(resolve_iso_url)"
  local base_url="${url%/*}"

  if [[ ! -f "$BASE_ISO" ]]; then
    log "Scarico ISO base: $url"
    curl -fL --retry 5 --retry-delay 10 -o "$BASE_ISO" "$url"
  else
    log "Uso ISO base gia presente: $BASE_ISO"
  fi

  log "Verifico SHA256 se disponibile..."
  curl -fL --retry 5 --retry-delay 5 -o "$WORK_DIR/SHA256SUMS" "${base_url}/SHA256SUMS" || {
    log "SHA256SUMS non scaricabile; salto verifica remota."
    return
  }
  (cd "$WORK_DIR" && sha256sum -c SHA256SUMS --ignore-missing)
}

extract_iso() {
  log "Estraggo ISO..."
  rm -rf "$EXTRACT_DIR" "$CHROOT_DIR"
  install -d "$EXTRACT_DIR"
  xorriso -osirrox on -indev "$BASE_ISO" -extract / "$EXTRACT_DIR" >/dev/null 2>&1
  chmod -R u+w "$EXTRACT_DIR"
}

find_root_squashfs() {
  local root_sq=""
  if [[ -f "$EXTRACT_DIR/casper/filesystem.squashfs" ]]; then
    root_sq="$EXTRACT_DIR/casper/filesystem.squashfs"
  else
    root_sq="$(
      find "$EXTRACT_DIR/casper" -maxdepth 1 -type f -name '*.squashfs' -printf '%s %p\n' \
        | sort -nr \
        | awk 'NR==1 {print $2}'
    )"
  fi

  [[ -n "$root_sq" && -f "$root_sq" ]] || die "Root squashfs non trovato in casper/"
  printf '%s\n' "$root_sq"
}

mount_chroot() {
  mount --bind /dev "$CHROOT_DIR/dev"
  mount --bind /dev/pts "$CHROOT_DIR/dev/pts"
  mount -t proc proc "$CHROOT_DIR/proc"
  mount -t sysfs sys "$CHROOT_DIR/sys"
  mount -t tmpfs tmpfs "$CHROOT_DIR/run"
}

umount_chroot() {
  local target
  for target in "$CHROOT_DIR/run" "$CHROOT_DIR/sys" "$CHROOT_DIR/proc" "$CHROOT_DIR/dev/pts" "$CHROOT_DIR/dev"; do
    if mountpoint -q "$target"; then
      umount -lf "$target" || true
    fi
  done
}

prepare_chroot_resolver() {
  log "Configuro DNS nel chroot..."
  rm -f "$CHROOT_DIR/etc/resolv.conf"

  if [[ -s /run/systemd/resolve/resolv.conf ]]; then
    cp /run/systemd/resolve/resolv.conf "$CHROOT_DIR/etc/resolv.conf"
  elif [[ -s /etc/resolv.conf ]] && ! grep -qE '127\.0\.0\.53|::1' /etc/resolv.conf; then
    cp /etc/resolv.conf "$CHROOT_DIR/etc/resolv.conf"
  else
    cat >"$CHROOT_DIR/etc/resolv.conf" <<'EOF'
nameserver 1.1.1.1
nameserver 8.8.8.8
options timeout:2 attempts:3
EOF
  fi
}

customize_rootfs() {
  local root_sq="$1"
  log "Estraggo filesystem live: $root_sq"
  unsquashfs -d "$CHROOT_DIR" "$root_sq" >/dev/null

  prepare_chroot_resolver
  install -d "$CHROOT_DIR/opt/astramind-glass-source"
  rsync -a --delete \
    --exclude '/work' \
    --exclude '/dist' \
    --exclude '/.git' \
    "$ROOT_DIR/" "$CHROOT_DIR/opt/astramind-glass-source/"

  mount_chroot
  trap umount_chroot EXIT

  log "Eseguo personalizzazione nel chroot..."
  chroot "$CHROOT_DIR" /bin/bash /opt/astramind-glass-source/iso/chroot-customize.sh

  umount_chroot
  trap - EXIT
}

update_manifests() {
  local root_sq="$1"
  log "Aggiorno manifest e filesystem.size..."
  chroot "$CHROOT_DIR" dpkg-query -W --showformat='${Package} ${Version}\n' > "$EXTRACT_DIR/casper/filesystem.manifest" || true
  cp "$EXTRACT_DIR/casper/filesystem.manifest" "$EXTRACT_DIR/casper/filesystem.manifest-desktop" || true
  du -sx --block-size=1 "$CHROOT_DIR" | awk '{print $1}' > "$EXTRACT_DIR/casper/filesystem.size"

  log "Ricompresso root filesystem..."
  rm -f "$root_sq"
  mksquashfs "$CHROOT_DIR" "$root_sq" -noappend -comp xz -b 1048576 -Xdict-size 100% >/dev/null
}

update_checksums() {
  log "Aggiorno md5sum.txt..."
  (
    cd "$EXTRACT_DIR"
    rm -f md5sum.txt
    find . -type f \
      ! -name md5sum.txt \
      ! -path './isolinux/boot.cat' \
      -print0 | sort -z | xargs -0 md5sum > md5sum.txt
  )
}

rebuild_iso() {
  log "Creo ISO finale: $OUTPUT_ISO"
  rm -f "$OUTPUT_ISO"

  # Replays the boot catalog and EFI/BIOS boot equipment from the official ISO.
  # This is more robust across Ubuntu ISO layout changes than hardcoding El Torito paths.
  xorriso \
    -indev "$BASE_ISO" \
    -outdev "$OUTPUT_ISO" \
    -map "$EXTRACT_DIR" / \
    -volid "$VOLUME_ID" \
    -boot_image any replay \
    -padding 0 \
    -compliance no_emul_toc \
    >/dev/null

  sha256sum "$OUTPUT_ISO" > "${OUTPUT_ISO}.sha256"
  log "ISO pronta:"
  log "$OUTPUT_ISO"
  log "${OUTPUT_ISO}.sha256"
}

cleanup() {
  umount_chroot || true
}

main() {
  require_root
  require_tools
  trap cleanup EXIT

  download_iso
  extract_iso
  local root_sq
  root_sq="$(find_root_squashfs)"
  customize_rootfs "$root_sq"
  update_manifests "$root_sq"
  update_checksums
  rebuild_iso
}

main "$@"
