#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="/opt/astramind-glass-source"

log() {
  printf '[chroot] %s\n' "$*"
}

export DEBIAN_FRONTEND=noninteractive
export ASTRA_ASSUME_YES=1
export ASTRA_FORCE=1
export ASTRA_SKIP_APPLY=1

configure_apt_sources() {
  local codename="${VERSION_CODENAME:-}"
  if [[ -z "$codename" && -r /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    codename="${VERSION_CODENAME:-}"
  fi
  codename="${codename:-resolute}"

  log "Configuro sorgenti APT per ${codename}..."
  install -d /etc/apt/sources.list.d

  while IFS= read -r -d '' source_file; do
    if grep -Eiq '(cdrom:|file:/cdrom|file:///cdrom)' "$source_file"; then
      mv "$source_file" "${source_file}.astramind-disabled"
    fi
  done < <(find /etc/apt -type f \( -name '*.list' -o -name '*.sources' \) -print0)

  cat >/etc/apt/sources.list.d/astramind-ubuntu.sources <<EOF
Types: deb
URIs: http://archive.ubuntu.com/ubuntu
Suites: ${codename} ${codename}-updates
Components: main restricted universe multiverse
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg

Types: deb
URIs: http://security.ubuntu.com/ubuntu
Suites: ${codename}-security
Components: main restricted universe multiverse
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg
EOF
}

apt_update_with_retry() {
  local attempt
  for attempt in 1 2 3; do
    if apt-get update; then
      return 0
    fi
    log "apt-get update fallito, tentativo ${attempt}/3."
    sleep $((attempt * 10))
  done
  return 1
}

configure_apt_sources

log "Preparo pacchetti minimi per AstraMind..."
apt_update_with_retry
apt-get install -y --no-install-recommends \
  ca-certificates \
  kde-cli-tools \
  kdialog \
  plasma-discover \
  python3 \
  sudo

log "Installo AstraMind nel filesystem live..."
bash "$SOURCE_DIR/install.sh"

log "Applico default utente in /etc/skel..."
install -d /etc/skel/.config /etc/skel/.local/share/applications /etc/skel/.config/autostart

cat >/etc/skel/.config/kdeglobals <<'EOF'
[General]
ColorScheme=AstraMindGlass
Name=AstraMindGlass
shadeSortColumn=true

[Icons]
Theme=breeze-dark

[KDE]
LookAndFeelPackage=com.astramind.glass
SingleClick=false
widgetStyle=Breeze
EOF

cat >/etc/skel/.config/ksplashrc <<'EOF'
[KSplash]
Theme=com.astramind.glass
EOF

cat >/etc/skel/.config/plasmarc <<'EOF'
[Theme]
name=AstraMindGlass
EOF

cat >/etc/skel/.config/kwinrc <<'EOF'
[org.kde.kdecoration2]
library=org.kde.breeze
theme=Breeze

[Windows]
BorderlessMaximizedWindows=false
EOF

cat >/etc/skel/.config/astramind-welcome.sh <<'EOF'
#!/usr/bin/env bash
if command -v kdialog >/dev/null 2>&1; then
  kdialog --title "AstraMind" --passivepopup "AstraMind e pronto. Prova: astramind 'configura wifi'" 8
fi
EOF
chmod 0755 /etc/skel/.config/astramind-welcome.sh

cat >/etc/skel/.config/autostart/astramind-welcome.desktop <<'EOF'
[Desktop Entry]
Type=Application
Name=AstraMind Welcome
Exec=sh -c "$HOME/.config/astramind-welcome.sh"
Icon=astramind
Terminal=false
X-KDE-autostart-after=panel
OnlyShowIn=KDE;
EOF

install -d /etc/skel/Desktop
cat >/etc/skel/Desktop/AstraMind.desktop <<'EOF'
[Desktop Entry]
Type=Application
Name=AstraMind
Comment=Assistente smart offline
Exec=astramind-gui
Icon=astramind
Terminal=false
Categories=Utility;KDE;
EOF
chmod 0755 /etc/skel/Desktop/AstraMind.desktop 2>/dev/null || true

log "Configuro tema SDDM..."
install -d /etc/sddm.conf.d
cat >/etc/sddm.conf.d/astramind-glass.conf <<'EOF'
[Theme]
Current=astramind-glass
EOF

log "Pulizia cache apt..."
apt-get clean
rm -rf /var/lib/apt/lists/* /tmp/* /var/tmp/*

log "Personalizzazione completata."
