#!/usr/bin/env python3
"""Small KDE-friendly front-end for AstraMind."""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys


def have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def kdialog_input() -> str:
    result = subprocess.run(
        ["kdialog", "--title", "AstraMind", "--inputbox", "Cosa vuoi fare?"],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    if result.returncode != 0:
        return ""
    return result.stdout.strip()


def terminal_input() -> str:
    try:
        return input("AstraMind> ").strip()
    except EOFError:
        return ""


def show_message(text: str, error: bool = False) -> None:
    title = "AstraMind"
    if have("kdialog"):
        option = "--error" if error else "--msgbox"
        subprocess.run(["kdialog", "--title", title, option, text], check=False)
        return
    print(text, file=sys.stderr if error else sys.stdout)


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="AstraMind GUI launcher")
    parser.add_argument("--query", help="richiesta da eseguire")
    parser.add_argument("files", nargs="*", help="file passati da Dolphin")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv if argv is not None else sys.argv[1:])
    query = args.query
    files = args.files

    if not query:
        query = kdialog_input() if have("kdialog") else terminal_input()
    if not query:
        return 0

    env = os.environ.copy()
    if files:
        env["ASTRAMIND_CONTEXT_FILES"] = "\n".join(files)

    command = ["astramind", query]
    result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env, check=False)
    show_message(result.stdout.strip() or "Operazione completata.", error=result.returncode != 0)
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())

