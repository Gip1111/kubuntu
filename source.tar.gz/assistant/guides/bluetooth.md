# Bluetooth

1. Apri Impostazioni Bluetooth.
2. Attiva Bluetooth.
3. Metti il dispositivo in modalita abbinamento.
4. Selezionalo dalla lista.
5. Conferma il codice se richiesto.

Se non appare, riavvia Bluetooth o avvicina il dispositivo.

