# Sicurezza

1. Mantieni il sistema aggiornato.
2. Installa software da fonti affidabili.
3. Usa firewall se esponi servizi in rete.
4. Non eseguire comandi root copiati da internet senza capire cosa fanno.

