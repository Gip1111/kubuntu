# File e cartelle

1. Usa Dolphin per navigare cartelle.
2. Tieni Documenti, Immagini e Download ordinati.
3. Usa nomi chiari e date nei file importanti.
4. Svuota Download ogni tanto.

