# Scrivere una email

1. Apri il client email o la webmail.
2. Inserisci destinatario, oggetto e testo.
3. Controlla allegati e destinatari.
4. Invia solo dopo verifica.

AstraMind puo aprire una bozza, ma l'invio deve restare una conferma dell'utente.

