# Password e KWallet

1. Usa password lunghe e uniche.
2. Attiva KWallet se vuoi salvare credenziali KDE.
3. Non condividere chiavi API o password in chat.
4. Per API AI future, salva la chiave nel portafoglio o in un file protetto.

