# Notifiche

1. Apri Impostazioni notifiche.
2. Scegli app e priorita.
3. Attiva Non disturbare quando lavori o giochi.
4. Disattiva notifiche inutili.

