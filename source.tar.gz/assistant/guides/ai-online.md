# AI online opzionale

Puoi usare ChatGPT, Gemini o altri servizi dal browser.

Questa modalita non richiede RAM locale per modelli AI, ma usa internet e dipende dal servizio scelto.

Non incollare password, dati sensibili o chiavi API in servizi esterni se non sai come verranno usati.

