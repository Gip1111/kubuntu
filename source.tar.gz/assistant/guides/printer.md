# Stampante e scanner

Stampante:

1. Apri Impostazioni stampanti.
2. Premi Aggiungi stampante.
3. Scegli USB, rete o Wi-Fi.
4. Stampa una pagina di prova.

Scanner:

1. Installa o apri Skanpage.
2. Seleziona lo scanner.
3. Esegui una scansione di prova.

