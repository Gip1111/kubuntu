# Aggiornare il sistema

1. Apri Discover.
2. Vai su Aggiornamenti.
3. Controlla la lista dei pacchetti.
4. Premi Aggiorna.
5. Riavvia se il sistema lo chiede.

AstraMind non avvia aggiornamenti root senza conferma.

