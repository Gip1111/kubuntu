# Audio e microfono

1. Apri Impostazioni audio.
2. Controlla dispositivo di uscita.
3. Controlla dispositivo di ingresso per il microfono.
4. Prova il volume.
5. Se usi HDMI o cuffie USB, selezionale manualmente.

