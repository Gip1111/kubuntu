# Installare un'app

Metodo consigliato:

1. Apri Discover.
2. Cerca il nome dell'app.
3. Controlla editore e descrizione.
4. Premi Installa.

Per app esterne come Google Chrome, scarica solo dal sito ufficiale del produttore.

