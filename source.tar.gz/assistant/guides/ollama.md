# Ollama opzionale

AstraMind v1 funziona senza Ollama.

Se vuoi AI locale:

- 8 GB RAM: prova modelli piccoli come `llama3.2:1b` o `gemma3:1b`.
- 8-16 GB RAM: prova `llama3.2:3b`.
- 16 GB+ RAM: puoi usare modelli piu grandi con piu comodita.

Comandi tipici dopo installazione di Ollama:

```bash
ollama pull llama3.2:3b
ollama run llama3.2:3b
```

La fase 2 di AstraMind potra usare il prefisso `ai ...` in KRunner e collegarsi a Ollama.

