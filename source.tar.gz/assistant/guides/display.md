# Schermo e monitor

1. Apri Impostazioni schermo.
2. Scegli risoluzione corretta.
3. Imposta scala se il testo e troppo piccolo.
4. Con piu monitor, trascina gli schermi nella posizione reale.
5. Applica e conferma.

