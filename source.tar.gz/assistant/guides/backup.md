# Backup file

Metodo semplice:

1. Collega un disco esterno.
2. Apri Dolphin.
3. Copia Documenti, Immagini, Desktop e cartelle importanti.
4. Verifica che i file siano leggibili dal disco esterno.

Metodo migliore:

1. Usa uno strumento di backup.
2. Mantieni almeno una copia esterna.
3. Non tenere l'unico backup nello stesso disco del PC.

