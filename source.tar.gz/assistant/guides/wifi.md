# Configurare Wi-Fi

1. Apri Impostazioni di sistema.
2. Vai su Rete o Connessioni.
3. Scegli la rete Wi-Fi.
4. Inserisci la password.
5. Se non funziona, spegni e riaccendi Wi-Fi dal pannello di rete.

Suggerimento: se la rete non appare, controlla che la modalita aereo sia disattivata.

