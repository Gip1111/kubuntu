# Creare un documento

1. Apri LibreOffice Writer.
2. Scrivi titolo e contenuto.
3. Salva subito il file.
4. Esporta in PDF se devi inviarlo.

Consiglio: salva in Documenti con un nome chiaro, per esempio `preventivo-2026.odt`.

