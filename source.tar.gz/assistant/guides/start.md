# AstraMind - guida rapida

AstraMind capisce richieste semplici e apre lo strumento KDE giusto.

Esempi:

- `configura wifi`
- `aggiorna sistema`
- `installa chrome`
- `tema scuro`
- `backup file`
- `scrivi email`
- `crea documento`
- `configura stampante`
- `apri chatgpt`

La v1 non usa un modello AI locale. Questo significa che funziona offline, e veloce e non consuma RAM extra. Le azioni rischiose richiedono conferma.

