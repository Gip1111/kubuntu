# Cambiare tema

1. Apri Impostazioni di sistema.
2. Vai su Aspetto.
3. Scegli Tema globale, Colori, Icone o Stile Plasma.
4. Applica e riavvia la sessione se qualche parte non cambia subito.

Il tema AstraMind Glass usa colori scuri e accenti luminosi.

