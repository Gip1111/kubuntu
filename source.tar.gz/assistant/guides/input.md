# Tastiera, mouse e touchpad

Tastiera:

1. Apri Impostazioni tastiera.
2. Controlla layout lingua.
3. Configura scorciatoie se necessario.

Mouse/touchpad:

1. Apri Impostazioni mouse.
2. Regola velocita puntatore e click.
3. Attiva o disattiva tap-to-click in base alle preferenze.

