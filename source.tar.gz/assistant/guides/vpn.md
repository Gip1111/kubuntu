# VPN

1. Apri Impostazioni rete.
2. Aggiungi nuova connessione VPN.
3. Scegli WireGuard, OpenVPN o il tipo indicato dal provider.
4. Inserisci configurazione e credenziali.
5. Connetti e verifica IP.

