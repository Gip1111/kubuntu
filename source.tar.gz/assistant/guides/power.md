# Energia e batteria

1. Apri Risparmio energetico.
2. Imposta profilo alimentazione.
3. Configura sospensione e spegnimento schermo.
4. Su notebook, controlla le azioni quando chiudi il coperchio.

