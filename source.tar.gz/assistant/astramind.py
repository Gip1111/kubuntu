#!/usr/bin/env python3
"""AstraMind smart assistant for KDE.

This is intentionally model-free for v1. It maps natural Italian requests to
safe desktop actions, offline guides and optional web shortcuts.
"""

from __future__ import annotations

import argparse
import difflib
import json
import os
import shutil
import subprocess
import sys
import unicodedata
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import Any


APP_NAME = "AstraMind"
DATA_PATHS = [
    Path("/usr/share/astramind/intents.json"),
    Path(__file__).resolve().parent / "intents.json",
]
GUIDE_DIRS = [
    Path("/usr/share/astramind/guides"),
    Path(__file__).resolve().parent / "guides",
]
MIN_SCORE = 34


@dataclass
class Match:
    score: float
    intent: dict[str, Any]
    phrase: str


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower()
    for char in "_-/.,;:!?()[]{}'\"":
        text = text.replace(char, " ")
    return " ".join(text.split())


def tokens(text: str) -> set[str]:
    stop = {"il", "lo", "la", "i", "gli", "le", "di", "a", "da", "in", "con", "per", "un", "una", "e"}
    return {token for token in normalize(text).split() if token and token not in stop}


def load_catalog() -> dict[str, Any]:
    for path in DATA_PATHS:
        if path.exists():
            with path.open("r", encoding="utf-8") as fh:
                return json.load(fh)
    raise SystemExit("Catalogo AstraMind non trovato.")


def guide_path(name: str | None) -> Path | None:
    if not name:
        return None
    for directory in GUIDE_DIRS:
        candidate = directory / name
        if candidate.exists():
            return candidate
    return None


def phrase_score(query: str, phrase: str) -> float:
    nq = normalize(query)
    np = normalize(phrase)
    if not nq or not np:
        return 0.0
    if nq == np:
        return 100.0
    if nq in np or np in nq:
        return 86.0

    ratio = difflib.SequenceMatcher(None, nq, np).ratio() * 70.0
    qt = tokens(nq)
    pt = tokens(np)
    overlap = 0.0
    if qt and pt:
        overlap = (len(qt & pt) / len(qt | pt)) * 35.0
    return ratio + overlap


def find_match(query: str, catalog: dict[str, Any]) -> Match | None:
    best: Match | None = None
    for intent in catalog.get("intents", []):
        phrases = [intent.get("trigger", ""), *intent.get("synonyms", [])]
        for phrase in phrases:
            score = phrase_score(query, phrase)
            if best is None or score > best.score:
                best = Match(score=score, intent=intent, phrase=phrase)
    if best and best.score >= MIN_SCORE:
        return best
    return None


def have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def format_cmd(command: list[str]) -> str:
    return " ".join(command)


def run_command(command: list[str], dry_run: bool = False) -> bool:
    if dry_run:
        print(f"[dry-run] {format_cmd(command)}")
        return True
    try:
        subprocess.Popen(command, start_new_session=True)
        return True
    except FileNotFoundError:
        return False
    except OSError as exc:
        print(f"Non riesco ad avviare {command[0]}: {exc}", file=sys.stderr)
        return False


def confirm(prompt: str, assume_yes: bool = False) -> bool:
    if assume_yes:
        return True
    if not sys.stdin.isatty():
        print("Azione non eseguita: serve conferma interattiva.")
        return False
    answer = input(f"{prompt} [s/N] ").strip().lower()
    return answer in {"s", "si", "y", "yes"}


def open_url(url: str, dry_run: bool = False) -> bool:
    if dry_run:
        print(f"[dry-run] apri URL: {url}")
        return True
    if have("xdg-open"):
        return run_command(["xdg-open", url])
    webbrowser.open(url)
    return True


def open_guide(name: str | None, dry_run: bool = False) -> bool:
    path = guide_path(name)
    if not path:
        return False
    print(f"Guida offline: {path}")
    if dry_run:
        return True
    if have("kdialog"):
        text = path.read_text(encoding="utf-8", errors="replace")
        subprocess.Popen(["kdialog", "--textbox", str(path), "760", "520"], start_new_session=True)
        if len(text) < 1200:
            print(text)
        return True
    if have("xdg-open"):
        return run_command(["xdg-open", str(path)])
    print(path.read_text(encoding="utf-8", errors="replace"))
    return True


def open_settings(kcm: str | None, fallback: str | None, dry_run: bool = False) -> bool:
    candidates: list[list[str]] = []
    if kcm:
        candidates.append(["kcmshell6", kcm])
        candidates.append(["systemsettings", kcm])
    if fallback:
        candidates.append(fallback.split())
    candidates.append(["systemsettings"])

    if dry_run:
        print(f"[dry-run] {format_cmd(candidates[0])}")
        return True

    for command in candidates:
        if command and have(command[0]):
            return run_command(command, dry_run=dry_run)
    print("Impostazioni KDE non trovate. Installa kde-cli-tools o apri Impostazioni di sistema manualmente.")
    return False


def open_discover(mode: str | None, search: str | None, dry_run: bool = False) -> bool:
    command = ["plasma-discover"]
    if mode:
        command.extend(["--mode", mode])
    if search:
        command.extend(["--search", search])
    if dry_run:
        print(f"[dry-run] {format_cmd(command)}")
        return True
    if not have("plasma-discover"):
        print("Discover non trovato. Apri il gestore pacchetti del tuo sistema.")
        return False
    return run_command(command, dry_run=dry_run)


def open_application(desktop_id: str | None, binary: str | None, dry_run: bool = False) -> bool:
    if dry_run:
        if desktop_id:
            print(f"[dry-run] gtk-launch {desktop_id}")
        elif binary:
            print(f"[dry-run] {binary}")
        return True
    if desktop_id and have("gtk-launch"):
        if run_command(["gtk-launch", desktop_id], dry_run=dry_run):
            return True
    if binary and have(binary):
        return run_command([binary], dry_run=dry_run)
    if desktop_id:
        print(f"Applicazione non trovata: {desktop_id}")
    elif binary:
        print(f"Applicazione non trovata: {binary}")
    return False


def apply_color_scheme(name: str, dry_run: bool = False) -> bool:
    if dry_run:
        print(f"[dry-run] plasma-apply-colorscheme {name}")
        return True
    if not have("plasma-apply-colorscheme"):
        print("plasma-apply-colorscheme non trovato. Apro Aspetto.")
        return open_settings("kcm_colors", None, dry_run=dry_run)
    return run_command(["plasma-apply-colorscheme", name], dry_run=dry_run)


def execute_action(intent: dict[str, Any], args: argparse.Namespace) -> bool:
    action = intent.get("action", {})
    kind = action.get("type", "guide")
    guide = intent.get("guide")

    if intent.get("needs_confirmation"):
        if args.dry_run:
            print("[dry-run] questa azione richiederebbe conferma utente.")
        elif not confirm(
            f"AstraMind vuole eseguire: {intent.get('trigger', intent.get('id'))}",
            assume_yes=args.yes,
        ):
            open_guide(guide, dry_run=args.dry_run)
            return False

    if kind == "open_settings":
        ok = open_settings(action.get("kcm"), action.get("fallback"), dry_run=args.dry_run)
    elif kind == "open_discover":
        ok = open_discover(action.get("mode"), action.get("search"), dry_run=args.dry_run)
    elif kind == "open_url":
        ok = open_url(action["url"], dry_run=args.dry_run)
    elif kind == "open_app":
        ok = open_application(action.get("desktop"), action.get("binary"), dry_run=args.dry_run)
    elif kind == "apply_color_scheme":
        ok = apply_color_scheme(action.get("scheme", "AstraMindGlass"), dry_run=args.dry_run)
    elif kind == "open_path":
        ok = run_command(["xdg-open", os.path.expanduser(action.get("path", "~"))], dry_run=args.dry_run)
    elif kind == "guide":
        ok = open_guide(guide, dry_run=args.dry_run)
    else:
        print(f"Azione sconosciuta: {kind}")
        ok = False

    if not ok and guide:
        print("Uso la guida offline come fallback.")
        open_guide(guide, dry_run=args.dry_run)
    return ok


def print_match(match: Match, context_files: list[str]) -> None:
    intent = match.intent
    print(f"{APP_NAME}: {intent.get('trigger', intent.get('id'))}")
    print(intent.get("description", ""))
    print(f"Corrispondenza: {match.score:.0f}% su '{match.phrase}'")
    if context_files:
        print("File selezionati:")
        for item in context_files[:12]:
            print(f"- {item}")
        if len(context_files) > 12:
            print(f"- ... altri {len(context_files) - 12}")


def list_intents(catalog: dict[str, Any]) -> None:
    for intent in catalog.get("intents", []):
        print(f"- {intent.get('trigger')} [{intent.get('id')}]")


def print_unknown(query: str, catalog: dict[str, Any]) -> None:
    print(f"{APP_NAME}: non ho trovato un comando sicuro per '{query}'.")
    print("Prova uno di questi:")
    for intent in catalog.get("intents", [])[:10]:
        print(f"- {intent.get('trigger')}")
    print("Puoi anche aprire ChatGPT o Gemini con: astramind \"chatgpt\"")


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="AstraMind smart assistant for KDE")
    parser.add_argument("query", nargs="*", help="richiesta in linguaggio naturale")
    parser.add_argument("--list", action="store_true", help="mostra i comandi disponibili")
    parser.add_argument("--dry-run", action="store_true", help="mostra cosa farebbe senza avviare app")
    parser.add_argument("--yes", action="store_true", help="conferma automaticamente le azioni consentite")
    parser.add_argument("--json", action="store_true", help="stampa il match in JSON")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv if argv is not None else sys.argv[1:])
    catalog = load_catalog()

    if args.list:
        list_intents(catalog)
        return 0

    query = " ".join(args.query).strip()
    if normalize(query) in {"list", "lista", "comandi", "lista comandi"}:
        list_intents(catalog)
        return 0

    if not query:
        print("Uso: astramind \"configura wifi\"")
        print("Oppure: astramind list")
        return 2

    context_files = [item for item in os.environ.get("ASTRAMIND_CONTEXT_FILES", "").splitlines() if item]
    match = find_match(query, catalog)
    if not match:
        print_unknown(query, catalog)
        return 1

    if args.json:
        print(json.dumps({"score": match.score, "intent": match.intent}, ensure_ascii=False, indent=2))
        return 0

    print_match(match, context_files)
    ok = execute_action(match.intent, args)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
